#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 30 13:37:50 2021

@author: Dr. Sörens
"""

import numpy as np

Q = np.random.randn()