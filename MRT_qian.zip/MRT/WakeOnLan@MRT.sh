echo "Wecke Rechner mrt-pc242"
sudo /root/bin/MRT/Wake-DHCP mrt-pc242
sleep 5
